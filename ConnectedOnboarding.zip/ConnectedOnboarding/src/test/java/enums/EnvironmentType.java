package enums;

public enum EnvironmentType {
 TEST,
  REMOTE,
 LOCAL;

}
