package StepDefinition;

import Pages.LoginPage;
import Utilities.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks extends DriverFactory {
    public static LoginPage loginPage;
    @Before
    public void setup(){
        init_Driver();
        loginPage = new LoginPage();
    }
    @After
    public void tearDown(){

        closeBrowser();
    }

}

