function() {
  var config = {
    baseUrl: 'https://yexledemo.appiancloud.com/suite/sites/aqua/page/home', // Replace with your base URL
    username: 'kiran123',
    password: 'Pass@123'
  };
  return config;
}
