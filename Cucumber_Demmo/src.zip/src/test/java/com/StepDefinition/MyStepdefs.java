package com.StepDefinition;

import PageObjects.AnimalDetailsPage;
import PageObjects.LoginPage;
import org.openqa.selenium.WebDriver;

public class MyStepdefs extends Login {
    WebDriver driver;

   // @io.cucumber.java.en.Given("User has been login on application")
    //public void userHasBeenLoginOnApplication() {


    //}
    public static AnimalDetailsPage animalDetails = new AnimalDetailsPage();


    @io.cucumber.java.en.And("User is on Zoo Details and Animal Details page")
    public void userIsOnZooDetailsAndAnimalDetailsPage() {
        animalDetails.verifyZooDetailPage();
        animalDetails.verifyAnimalDetailspage();
    }

    @io.cucumber.java.en.When("User click on {string} button")
    public void userClickOnAddAnimalDetailsButton() {
        animalDetails.AddAnimalDetails();

    }

    @io.cucumber.java.en.And("User on Add animal Details page")
    public void userOnAddAnimalDetailsPage() {
        animalDetails.verify_AddAnimalPage();
    }

    @io.cucumber.java.en.And("User enters the following details:")
    public void userEntersTheFollowingDetails(String AnimalName, String SpecieType, String PenName,String AnimalAge, String Gender,String AnimalCharacterstics) throws InterruptedException {
        animalDetails.AddAnimalName( AnimalName);
        animalDetails.AnimalCharacterstics(AnimalCharacterstics);
        animalDetails.SpecieType(SpecieType);
        animalDetails.PenName( PenName);
        animalDetails.GenderOfAnimal( Gender);
        animalDetails.animalAge( AnimalAge);
        animalDetails.uploadPhoto();
        animalDetails.submit();
    }

    @io.cucumber.java.en.And("Upload Animal Photo")
    public void uploadAnimalPhoto() {
    }

    @io.cucumber.java.en.And("click on Submit button")
    public void clickOnSubmitButton() {
    }

    @io.cucumber.java.en.Then("Message Displayed - {string}")
    public void messageDisplayedAnimalsAddInZooSuccessfully() {
    }

    @io.cucumber.java.en.And("User is on {string} page")
    public void userIsOnAnimalsDetailPage() {
    }

    @io.cucumber.java.en.Given("User has been logged in on application")
    public void userHasBeenLoggedInOnApplication() {
    }

    @io.cucumber.java.en.And("User is on Zoo Details page")
    public void userIsOnZooDetailsPage() {
    }

    @io.cucumber.java.en.And("User has been Added Animal and pens to Zoo")
    public void userHasBeenAddedAnimalAndPensToZoo() {
    }

    @io.cucumber.java.en.Given("User is on Animal Details page")
    public void userIsOnAnimalDetailsPage() {
    }

    @io.cucumber.java.en.When("User selects appropriate {string}")
    public void userSelectsAppropriateSpecieType() {
    }

    @io.cucumber.java.en.And("User select appropriate Gender of animal")
    public void userSelectAppropriateGenderOfAnimal() {
    }

    @io.cucumber.java.en.Then("List of Animals with suitable Specie Type and Gender is displayed")
    public void listOfAnimalsWithSuitableSpecieTypeAndGenderIsDisplayed() {
    }

    @io.cucumber.java.en.When("User select {string} from dropdown")
    public void userSelectPenNameFromDropdown() {
    }

    @io.cucumber.java.en.Then("List of Animals with pen name, Special name,age ,Charecterstics and isActive is displayed")
    public void listOfAnimalsWithPenNameSpecialNameAgeCharectersticsAndIsActiveIsDisplayed() {
    }

    @io.cucumber.java.en.When("user enter animal's name or ID in animal search box")
    public void userEnterAnimalSNameOrIDInAnimalSearchBox() {
    }

    @io.cucumber.java.en.And("Click on {string} button")
    public void clickOnSearchButton() {
    }

    @io.cucumber.java.en.Then("Animal with pen name, Special name,age ,Charecterstics and isActive is displayed")
    public void animalWithPenNameSpecialNameAgeCharectersticsAndIsActiveIsDisplayed() {
    }
}
